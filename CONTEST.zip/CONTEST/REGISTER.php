<?php require_once('includes/header.php'); ?>
<html>

<head>
   <meta charset='utf-8'>

<style>
body
{
background-image:url('picture/o-ONLINE-DATING-facebook.jpg');
}
</style>

</head> 
<body>
    <nav class="navbar navbar-default">
        <div class="navbar-header">
            <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
          
        </div>
      
                 <div id="navbarCollapse" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
               <a href="#" class="navbar-brand">Home</a></li>
                <a href="profile.php" class="navbar-brand">Profile</a></li>
                <a href="#" class="navbar-brand">Messages</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
             <a href="login.php" class="navbar-brand">Login</a>
                <a href="register.php" class="navbar-brand">Register</a>
                <a href="Contact.php" class="navbar-brand">Contact Us</a></li>
            </ul>
        
    </nav>
</div>
</body>
</html>

	<div class="container-fluid">
	<div class="row">
		<div class="col-md-5 col-md-offset-3">

			<div style="margin-top:50px;"><legend><center><h2>Register</legend></div></center></h2>
			<div class="alert alert-danger" id="validateRegister" style="display: none"></div>
			<form action="users/actions/users/user_registration.php" method="POST" id="register">

					<div class="form-group">
						<label>Name:<span style="color:red">*</span> </label>
						<input type="text" class="form-control" id="name" name="name" placeholder="name" />
					</div>

					<div class="form-group">
						<label>Birthdate: <span style="color:red">*</span> </label>
						<input type="text" class="form-control" id="birthdate" name="birthdate" placeholder="Birthdate" />
						<br>
						<div class="form-group">
						<div class="dropdown">
							<div class="form-group">
						<label>Address: <span style="color:red">*</span> </label>
						<input type="text" class="form-control" id="address" name="address" placeholder="Complete Address" />
						<br>
						<div class="form-group">
						<div class="dropdown">

						<div class="form-group">
												<div class="dropdown">
											   <label>Age: </label>&nbsp;
											    <select name="Age">
											    <span class="caret"></span></button>
											    <ul class="dropdown-menu">
									
											     <option value="18">18</option>
											    <option value="19">19</option>
											     <option value="20">20</option>
											     <option value="21">21</option> 
											     <option value="22">22</option>
											    <option value="23">23</option>
											     <option value="24">24</option>
											     <option value="25">25</option> 

											     </ul>
											     </select>
											     </div>
											     </div>

						
							<div class="form-group">
												<div class="dropdown">
											   <label>Gender: </label>&nbsp;
											    <select name="Gender">
											    <span class="caret"></span></button>
											    <ul class="dropdown-menu">
									
											      <option value="Female">Female</option>
											    <option value="Male">Male</option>
											     <option value="Lesbian">Lesbian</option>
											     <option value="Gay">Gay</option> 

											     </ul>
											     </select>
											     </div>
											     </div>

							<div class="form-group">
						<label>E-mail: <span style="color:red">*</span> </label>
						<input type="text" class="form-control" id="email_address" name="email_address" placeholder="Email Address" />
						<br>
						<div class="form-group">
						<div class="dropdown">
							<div class="form-group">
						<label>Contact Number: <span style="color:red">*</span> </label>
						<input type="text" class="form-control" id="contact_number" name="contact_number" placeholder="Contact Number" />
						<br>
						<div class="form-group">
						<div class="dropdown">




					<div class="form-group">
					<label>Username: </label><span style="color:red">*</span>
					<input type="text" name="username" id="username" name="Username" placeholder="Username" class="form-control">
					<br>

					<div class="form-group">
					<label>Password:<span style="color:red">*</span> </label>
					<input type="password" name="password" id="password" placeholder="Password" name="Password" class="form-control">
				</div>

				
					  <div class="form-group">
					    <br>
				    <div class="col-sm-offset-4 col-sm-6">
				      <button type="submit" class="btn btn-danger">Create an Account</button>
				      &nbsp;
				      <button type="cancel" class="btn btn-default" formaction="/LOGIN.php">Cancel</button>

	

					  </form>
					</div>

					</div>
		</div>
	</div>
</div>

<?php require_once('includes/footer.php'); ?>
            
	