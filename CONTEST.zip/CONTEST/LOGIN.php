  <?php require_once('includes/header.php');

if(!empty($_SESSION['username']))
{
  header('Location: editprofile.php');
}
?>
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet'  type='text/css'>
<html>
<head>
   <meta charset='utf-8'>

<style>
body
{
background-image:url('picture/o-ONLINE-DATING-facebook.jpg');
}
.navbar .nav > li > a{
font-size:14px;
}

</style>

</head> 
<body>
    <nav class="navbar navbar-default">
        <div class="navbar-header">
            <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            
        </div>
      
              <div id="navbarCollapse" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
               <a href="#" class="navbar-brand">Home</a></li>
                <a href="profile.php" class="navbar-brand">Profile</a></li>
                <a href="#" class="navbar-brand">Messages</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
             <a href="login.php" class="navbar-brand">Login</a>
                <a href="register.php" class="navbar-brand">Register</a>
                <a href="Contact.php" class="navbar-brand">Contact Us</a></li>
            </ul>
            </div>
        
    </nav>
</div>
</body>
</html>

<form action="users/actions/login.php" method="POST" class="form-horizontal">
<br>
<br>
<br>
<br>
<br>
<br>
<h1><center><font style="'Open Sans', sans-serif;">Please log In</center></h1></font>
  <div class="form-group">
    <label for="username" class="col-sm-4 control-label">Username</label>
    <div class="col-sm-4">
      <input type="text" name="username" class="form-control" required id="username" placeholder="username">
    </div>
  </div>

  <div class="form-group">
    <label for="password" class="col-sm-4 control-label">Password</label>
    <div class="col-sm-4">
      <input type="password" name="password" class="form-control" required id="password" placeholder="Password">
    </div>
  </div>
  <div c
  lass="form-group">
    <div class="col-sm-offset-5 col-sm-6">
      <input type="submit" name="submit" value="Submit" class="btn btn-danger">
        <div class="form-group">
        <br>
        <p>Don't have an account? 

        <a href ="REGISTER.php">Sign-up</a>
        </p>
      </div>
    </div>
</div>
</form>