<?php

class Session
{
    public static function get($key, $remove = false) {
        $value = !empty($_SESSION[$key])
            ? $_SESSION[$key] //<--
            : false;
        if ($remove) {
            unset($_SESSION[$key]);
        }
        return $value;
    }

    public static function put($key, $value) {
        $_SESSION[$key] = $value;
    }

    public static function destroy() {
        session_unset();
        session_destroy();
    }
}