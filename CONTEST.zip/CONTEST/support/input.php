<?php

class Input
{
    public static function get($key) {
        return !empty($_REQUEST[$key]) 
                ? $_REQUEST[$key]
                : false;
                //kahit $_POST or $_GET mkukuha nyan.. ganyan pala gumawa ng mga Input::get
                //malake yun sa laravel . .eto pan sakin lan . . saan mo ni implementyan pang
    }
}