<?php
require_once('db.php');


$username = $_POST['username'];
$password = $_POST['password'];
$userlevel;

$user_query = "select * from users where username = '".$username."' AND password ='".$password."'";
$users= mysqli_query($db,$user_query) or die(mysqli_error($db));
$result = mysqli_fetch_assoc($users);

if($result['user_level'] == 1){
	$_SESSION['username'] = $username;
	$userlevel = $_SESSION['user_level'] = $result['user_level'];
	$_SESSION['user_id'] = $result['id'];
	header('location: admin.php');
}	else if($result['user_level'] == 2){
	$_SESSION['username'] = $username;
	$userlevel = $_SESSION['user_level'] = $result['user_level'];
	$_SESSION['user_id'] = $result['id'];
	header('location: profile.php');
}

?>