<?php
require_once('../../../database/db.php');
require_once('../../../support/input.php');

$name = Input::get('name');
$birthdate= Input::get('birthdate');
$address= Input::get('address');
$age = Input::get('age');
$gender = Input::get('gender');

$email = Input::get('email_address');
$contact = Input::get('contact_number');

$username = Input::get('username');
$password = Input::get('password');

$userlevel = 2;




$user_query = "insert into users values(NUll,'$username','$password','$userlevel')";
$users = mysqli_query($db,$user_query);


$user_contact_query = "insert into users_contact values(NULL,'$db->insert_id','$contact','$email')";
mysqli_query($db,$user_contact_query);

$user_profile_query = "insert into users_profile values(Null,'$db->insert_id','$name','$birthdate','$address','$age','$gender')";
mysqli_query($db,$user_profile_query);
header('Location: ../../../login.php');
