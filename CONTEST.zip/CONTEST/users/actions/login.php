<?php
session_start();
require_once('../../database/db.php');
require_once('../../support/input.php');
require_once('../../support/session.php');

$userlevel;
$email = Input::get('username');
$password = Input::get('password');


if($email && $password)
{
	$login_query = "select * from users where username='$email' and password='$password' and userlevel='2'";
	$login = mysqli_query($db,$login_query) or die(mysqli_error($db));
	$login_result = mysqli_fetch_assoc($login);
	if($login_result)
	{
		Session::put('username',$login_result['username']);
		Session::put('user_id', $login_result['id']);
		header('Location: ../../profile.php');
	}	else
	{	
		header('Location: ../../admin.php');
	}
	
}




?>