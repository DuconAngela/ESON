<?php
require_once("../database/db.php");
require_once('../support/input.php');
$country_name = Input::get('country_name');
$short_term = Input::get('short_term');
$zip_code = Input::get('zip_code');
$insert_country_query = "insert into countries values(NULL,'$short_term','$zip_code','$country_name')";


mysqli_query($db,$insert_country_query);
header('location: ../addcountry.php');
?>