<?php
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'contest';

$db = mysqli_connect($host,$user,$password,$database);
?>